# Car-Rental-System
Car Rental System is a java and data base project it is used to store the information about the  Available cars, Customers, Rental details and return details at the owner site. 
